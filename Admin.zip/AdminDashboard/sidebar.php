    <ul class="sidebar navbar-nav">

      <li class="nav-item active">
        <a class="nav-link" href="index.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="datatransaksi.php">
          <i class="fas fa-fw fa-tasks"></i>
          <span>Data Transaksi</span></a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="tambahtransaksi.php" >
          <i class="fas fa-fw fa-plus" ></i>
          <span>Tambah Transaksi</span></a>
      </li>
		
		<li class="nav-item">
        <a class="nav-link" href="datamember.php">
          <i class="fas fa-fw fa-users"></i>
          <span>Data Member</span></a>  
      </li>
		<li class="nav-item">
        <a class="nav-link" href="tambahmember.php" onclick="ambilDataTerakhir()">
          <i class="fas fa-fw fa-user-plus"></i>
          <span>Tambah Member</span>
		</a>          
      </li>
            <li class="nav-item">
        <a class="nav-link" href="rekapitulasi.php">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>Statistik Pemasukkan</span></a>
      </li>
    </ul>
